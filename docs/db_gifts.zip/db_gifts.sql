-- Adminer 4.8.1 MySQL 8.0.33-0ubuntu0.22.04.2 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `gift`;
CREATE TABLE `gift` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int unsigned DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int NOT NULL,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gift` (`id`, `name`, `category_id`, `picture`, `price`, `created_by`, `updated_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Samsung S22',	1,	'default.jpg',	2000000,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(2,	'Mito 5G',	2,	'default.jpg',	2400000,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(3,	'Lenovo 7+',	NULL,	'default.jpg',	1000000,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(4,	'Iphone 9',	1,	'default.jpg',	5000000,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(5,	'Xiaomi Redmi 2X',	3,	'default.jpg',	3000000,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL);

DROP TABLE IF EXISTS `gift_category`;
CREATE TABLE `gift_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gift_category` (`id`, `name`, `created_by`, `updated_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Best Seller',	1,	1,	NULL,	'2023-07-23 17:13:17',	'2023-07-23 17:13:17',	NULL),
(2,	'New',	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(3,	'Hot Item',	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL);

DROP TABLE IF EXISTS `gift_detail`;
CREATE TABLE `gift_detail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `gift_id` int NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gift_detail` (`id`, `gift_id`, `description`, `created_by`, `updated_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	'lorem ipsum dolor sit amet.. Samsung',	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(2,	2,	'lorem ipsum dolor sit amet.. Mito',	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(3,	3,	'lorem ipsum dolor sit amet.. Lenovo',	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(4,	4,	'lorem ipsum dolor sit amet.. Iphone',	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(5,	5,	'lorem ipsum dolor sit amet.. Xiaomi',	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL);

DROP TABLE IF EXISTS `gift_redeem`;
CREATE TABLE `gift_redeem` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `gift_id` int NOT NULL,
  `qty` int NOT NULL,
  `price_item` int NOT NULL,
  `total` int NOT NULL,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `gift_review`;
CREATE TABLE `gift_review` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `gift_id` int NOT NULL,
  `rating` int NOT NULL,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `gift_stock`;
CREATE TABLE `gift_stock` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `gift_id` int NOT NULL,
  `stock` int NOT NULL,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gift_stock` (`id`, `gift_id`, `stock`, `created_by`, `updated_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	50,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(2,	2,	100,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(3,	3,	50,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(4,	4,	45,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL),
(5,	5,	45,	1,	1,	NULL,	'2023-07-23 17:13:18',	'2023-07-23 17:13:18',	NULL);

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(5,	'2023_07_21_130139_create_permission_tables',	1),
(6,	'2023_07_21_141304_create_table_gift',	1),
(7,	'2023_07_21_141316_create_table_gift_detail',	1),
(8,	'2023_07_21_141324_create_table_gift_review',	1),
(9,	'2023_07_21_141331_create_table_gift_stock',	1),
(10,	'2023_07_21_141348_create_table_gift_redeem',	1),
(11,	'2023_07_21_141523_create_table_gift_category',	1);

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1,	'App\\Models\\User',	1),
(2,	'App\\Models\\User',	2);

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1,	'user',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(2,	'tambah user',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(3,	'edit user',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(4,	'hapus user',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(5,	'lihat user',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(6,	'permission',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(7,	'tambah permission',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(8,	'edit permission',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(9,	'hapus permission',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(10,	'lihat permission',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(11,	'role',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(12,	'tambah role',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(13,	'edit role',	'api',	'2023-07-23 17:13:02',	'2023-07-23 17:13:02'),
(14,	'hapus role',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(15,	'lihat role',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(16,	'gift',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(17,	'tambah gift',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(18,	'edit gift',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(19,	'hapus gift',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(20,	'lihat gift',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(21,	'gift kategori',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(22,	'tambah gift kategori',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(23,	'edit gift kategori',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(24,	'hapus gift kategori',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(25,	'lihat gift kategori',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(26,	'redeem',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(27,	'rating',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03');

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1,	1),
(2,	1),
(3,	1),
(4,	1),
(5,	1),
(6,	1),
(7,	1),
(8,	1),
(9,	1),
(10,	1),
(11,	1),
(12,	1),
(13,	1),
(14,	1),
(15,	1),
(16,	1),
(17,	1),
(18,	1),
(19,	1),
(20,	1),
(21,	1),
(22,	1),
(23,	1),
(24,	1),
(25,	1),
(26,	1),
(27,	1),
(16,	2),
(20,	2),
(21,	2),
(26,	2),
(27,	2);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1,	'super admin',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(2,	'user',	'api',	'2023-07-23 17:13:03',	'2023-07-23 17:13:03');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'Super Admin',	'super@admin.com',	NULL,	'$2y$10$EPq3c8e2DKxB6Nlfn3WDK.hzs9p2rv3YS6ZEXypae/o6VCQJil7pq',	NULL,	'2023-07-23 17:13:03',	'2023-07-23 17:13:03'),
(2,	'User Example',	'user@example.com',	NULL,	'$2y$10$bt8FNtF79QL8lX6VTPGCtOOWTSlz4CAoa2FjcwY7ZIpDULyKvp.Nm',	NULL,	'2023-07-23 17:13:04',	'2023-07-23 17:13:04');

-- 2023-07-23 17:13:27
